package com.example.retoursmixer.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.retoursmixer.MixerViewModel
import com.example.retoursmixer.Screen
import com.example.retoursmixer.data.Profile
import com.example.retoursmixer.data.resolveTracks
import kotlin.math.abs
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileEditorScreen(vm: MixerViewModel, profileId: String?) {
    val existing = vm.profileById(profileId)
    var draft by remember(profileId) { mutableStateOf(existing ?: Profile()) }
    var confirmDelete by remember { mutableStateOf(false) }

    val groupNames = vm.tracks.filter { it.isGroup }.map { it.name }
    val resolved = resolveTracks(vm.tracks, draft)
    // Liste complète des pistes concernées par le profil, avant masquage, pour cocher / décocher.
    val candidates = resolveTracks(vm.tracks, draft.copy(hidden = emptySet())).tracks

    fun finish() {
        vm.back()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = { finish() }) { Text("‹ Annuler") }
            Text(
                text = if (existing == null) "Nouveau profil" else "Modifier le profil",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
            )
        }

        OutlinedTextField(
            value = draft.name,
            onValueChange = { draft = draft.copy(name = it) },
            label = { Text("Nom du profil (ex. Will)") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
        )

        SectionTitle("Groupe de pistes Ableton à afficher")
        Row(
            modifier = Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            FilterChip(
                selected = draft.groupName.isBlank(),
                onClick = { draft = draft.copy(groupName = "") },
                label = { Text("Toutes les pistes") },
            )
            groupNames.forEach { g ->
                FilterChip(
                    selected = draft.groupName.trim().equals(g.trim(), ignoreCase = true),
                    onClick = { draft = draft.copy(groupName = g) },
                    label = { Text(g) },
                )
            }
        }
        if (groupNames.isEmpty()) {
            Hint("Aucun groupe détecté (Ableton non connecté ?). Tu peux saisir le nom à la main ci-dessous.")
        }
        OutlinedTextField(
            value = draft.groupName,
            onValueChange = { draft = draft.copy(groupName = it) },
            label = { Text("Nom exact du groupe (ex. Retours Will)") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
        )
        if (draft.groupName.isBlank()) {
            OutlinedTextField(
                value = draft.nameFilter,
                onValueChange = { draft = draft.copy(nameFilter = it) },
                label = { Text("Ou : pistes dont le nom contient… (optionnel)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
            )
        }

        HorizontalDivider()
        SectionTitle("Ce que le musicien voit")
        SwitchRow(
            label = "Fader du groupe lui-même",
            checked = draft.showGroupFader,
            onChange = { draft = draft.copy(showGroupFader = it) },
            hint = "Un volume général pour tout son retour.",
        )
        SwitchRow("Bouton Mute", draft.showMute) { draft = draft.copy(showMute = it) }
        SwitchRow("Vumètres", draft.showMeters) { draft = draft.copy(showMeters = it) }

        val limitPct = (draft.maxVolume * 100).roundToInt()
        val limitLabel = if (abs(draft.maxVolume - ZERO_DB) < 0.005f) "$limitPct % (= 0 dB)" else "$limitPct %"
        Text("Limite haute du fader : $limitLabel", fontWeight = FontWeight.Medium)
        Slider(
            value = draft.maxVolume,
            onValueChange = { draft = draft.copy(maxVolume = (it * 100).roundToInt() / 100f) },
            valueRange = 0.5f..1f,
            steps = 49,
        )
        Hint("Le musicien ne pourra pas monter son fader au-delà. 85 % correspond à 0 dB dans Ableton.")

        SectionTitle("Couleur")
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            ProfileColors.forEachIndexed { i, c ->
                Box(
                    Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(c)
                        .then(
                            if (draft.colorIndex == i) Modifier.border(3.dp, Color.White, CircleShape)
                            else Modifier
                        )
                        .clickable { draft = draft.copy(colorIndex = i) }
                )
            }
        }

        HorizontalDivider()
        SectionTitle("Pistes affichées")
        if (vm.tracks.isEmpty()) {
            Hint("Connecte-toi à Ableton pour voir la liste des pistes et pouvoir en masquer.")
        } else if (resolved.groupMissing) {
            Hint("Ce groupe n'existe pas dans le set Ableton actuel.")
        } else {
            candidates.forEach { t ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(
                        checked = t.name !in draft.hidden,
                        onCheckedChange = { on ->
                            draft = draft.copy(hidden = if (on) draft.hidden - t.name else draft.hidden + t.name)
                        },
                    )
                    Text(t.name)
                }
            }
        }

        Spacer(Modifier.height(4.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(
                onClick = {
                    vm.saveProfile(draft.copy(name = draft.name.trim().ifBlank { "Profil" }))
                    finish()
                },
                modifier = Modifier.weight(1f),
            ) { Text("Enregistrer") }
            OutlinedButton(onClick = { finish() }, modifier = Modifier.weight(1f)) { Text("Annuler") }
        }
        if (existing != null) {
            TextButton(onClick = { confirmDelete = true }) {
                Text("Supprimer ce profil", color = MaterialTheme.colorScheme.error)
            }
        }
        Spacer(Modifier.height(24.dp))
    }

    if (confirmDelete && existing != null) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("Supprimer « ${existing.name} » ?") },
            text = { Text("Cette action est définitive sur ce téléphone.") },
            confirmButton = {
                TextButton(onClick = {
                    confirmDelete = false
                    vm.deleteProfile(existing.id)
                    vm.goHome()
                }) { Text("Supprimer", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = {
                TextButton(onClick = { confirmDelete = false }) { Text("Annuler") }
            },
        )
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(text, fontWeight = FontWeight.Bold, fontSize = 16.sp)
}

@Composable
private fun Hint(text: String) {
    Text(text, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
}

@Composable
private fun SwitchRow(
    label: String,
    checked: Boolean,
    hint: String? = null,
    onChange: (Boolean) -> Unit,
) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(label)
            if (hint != null) Hint(hint)
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}
