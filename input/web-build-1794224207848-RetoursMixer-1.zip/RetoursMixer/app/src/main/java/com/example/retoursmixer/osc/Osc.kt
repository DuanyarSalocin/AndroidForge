package com.example.retoursmixer.osc

import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer

/** Message OSC décodé : une adresse et une liste d'arguments (Int, Float, String, Boolean, Long, Double...). */
data class OscMessage(val address: String, val args: List<Any?>)

fun Any?.asFloat(): Float? = (this as? Number)?.toFloat()

fun Any?.asInt(): Int? = (this as? Number)?.toInt()

fun Any?.asBool(): Boolean? = when (this) {
    is Boolean -> this
    is Number -> this.toInt() != 0
    else -> null
}

/** Encodage / décodage minimal du protocole OSC 1.0 (suffisant pour AbletonOSC). */
object Osc {

    // ---------- Encodage ----------

    fun encode(address: String, args: List<Any?>): ByteArray {
        val out = ByteArrayOutputStream()
        writePaddedString(out, address)

        val tags = StringBuilder(",")
        for (a in args) {
            when (a) {
                is Int -> tags.append('i')
                is Float -> tags.append('f')
                is String -> tags.append('s')
                else -> throw IllegalArgumentException("Type OSC non géré : ${a?.javaClass?.name}")
            }
        }
        writePaddedString(out, tags.toString())

        for (a in args) {
            when (a) {
                is Int -> out.write(ByteBuffer.allocate(4).putInt(a).array())
                is Float -> out.write(ByteBuffer.allocate(4).putFloat(a).array())
                is String -> writePaddedString(out, a)
            }
        }
        return out.toByteArray()
    }

    private fun writePaddedString(out: ByteArrayOutputStream, s: String) {
        val bytes = s.toByteArray(Charsets.UTF_8)
        out.write(bytes)
        // Terminateur nul + remplissage pour tomber sur un multiple de 4 octets.
        val pad = 4 - (bytes.size % 4)
        repeat(pad) { out.write(0) }
    }

    // ---------- Décodage ----------

    fun decode(data: ByteArray, length: Int): List<OscMessage> {
        val result = ArrayList<OscMessage>()
        try {
            parsePacket(data, 0, length, result)
        } catch (e: Exception) {
            // Paquet mal formé : on garde ce qui a déjà été décodé.
        }
        return result
    }

    private fun parsePacket(d: ByteArray, start: Int, end: Int, out: MutableList<OscMessage>) {
        if (end - start >= 16 && String(d, start, 7, Charsets.US_ASCII) == "#bundle") {
            var p = start + 16 // "#bundle\0" (8 octets) + timetag (8 octets)
            while (p + 4 <= end) {
                val size = ByteBuffer.wrap(d, p, 4).int
                p += 4
                if (size <= 0 || p + size > end) break
                parsePacket(d, p, p + size, out)
                p += size
            }
            return
        }
        parseMessage(d, start, end)?.let { out.add(it) }
    }

    private class Cursor(val d: ByteArray, var p: Int, val end: Int)

    private fun Cursor.readString(): String {
        var e = p
        while (e < end && d[e] != 0.toByte()) e++
        val s = String(d, p, e - p, Charsets.UTF_8)
        p = (e + 4) and 3.inv()
        return s
    }

    private fun Cursor.readInt(): Int {
        val v = ByteBuffer.wrap(d, p, 4).int
        p += 4
        return v
    }

    private fun Cursor.readFloat(): Float {
        val v = ByteBuffer.wrap(d, p, 4).float
        p += 4
        return v
    }

    private fun Cursor.readLong(): Long {
        val v = ByteBuffer.wrap(d, p, 8).long
        p += 8
        return v
    }

    private fun Cursor.readDouble(): Double {
        val v = ByteBuffer.wrap(d, p, 8).double
        p += 8
        return v
    }

    private fun parseMessage(d: ByteArray, start: Int, end: Int): OscMessage? {
        val c = Cursor(d, start, end)
        val address = c.readString()
        if (!address.startsWith("/")) return null
        if (c.p >= end) return OscMessage(address, emptyList())

        val tags = c.readString()
        if (!tags.startsWith(",")) return OscMessage(address, emptyList())

        val args = ArrayList<Any?>()
        for (t in tags.substring(1)) {
            when (t) {
                'i' -> args.add(c.readInt())
                'f' -> args.add(c.readFloat())
                's', 'S' -> args.add(c.readString())
                'h' -> args.add(c.readLong())
                'd' -> args.add(c.readDouble())
                't' -> c.p += 8
                'T' -> args.add(true)
                'F' -> args.add(false)
                'N' -> args.add(null)
                'I' -> {}
                'c', 'r', 'm' -> c.p += 4
                'b' -> {
                    val n = c.readInt()
                    args.add(d.copyOfRange(c.p, c.p + n))
                    c.p = (c.p + n + 3) and 3.inv()
                }
                else -> return OscMessage(address, args)
            }
        }
        return OscMessage(address, args)
    }
}
