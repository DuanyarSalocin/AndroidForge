package com.example.retoursmixer.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.retoursmixer.MixerViewModel
import com.example.retoursmixer.Screen
import com.example.retoursmixer.data.Profile

@Composable
fun HomeScreen(vm: MixerViewModel) {
    Column(
        Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = "Ninth Retour Live",
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f),
            )
            ConnectionBadge(vm.connected)
            TextButton(onClick = { vm.go(Screen.Settings) }) { Text("Réglages") }
        }
        Spacer(Modifier.height(4.dp))
        Text(
            text = "Choisis l'interface de retour à ouvrir.",
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            fontSize = 14.sp,
        )
        Spacer(Modifier.height(12.dp))

        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            if (vm.profiles.isEmpty()) {
                item {
                    Text(
                        text = "Aucun profil pour l'instant.\nAppuie sur « + Nouveau profil » pour créer " +
                            "l'interface d'un musicien et l'assigner à son groupe de retours.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(vertical = 24.dp),
                    )
                }
            }
            items(vm.profiles, key = { it.id }) { p ->
                ProfileCard(
                    profile = p,
                    onOpen = { vm.go(Screen.Mixer(p.id)) },
                    onEdit = { vm.go(Screen.Editor(p.id)) },
                )
            }
        }

        Spacer(Modifier.height(10.dp))
        Button(
            onClick = { vm.go(Screen.Editor(null)) },
            modifier = Modifier.fillMaxWidth(),
        ) { Text("+ Nouveau profil") }
    }
}

@Composable
private fun ProfileCard(profile: Profile, onOpen: () -> Unit, onEdit: () -> Unit) {
    val subtitle = when {
        profile.groupName.isNotBlank() -> "Groupe : ${profile.groupName}"
        profile.nameFilter.isNotBlank() -> "Pistes contenant « ${profile.nameFilter} »"
        else -> "Toutes les pistes"
    }
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onOpen),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(72.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(
                Modifier
                    .width(8.dp)
                    .fillMaxHeight()
                    .background(profileColor(profile.colorIndex))
            )
            Column(
                modifier = Modifier
                    .weight(1f)
                    .padding(horizontal = 16.dp)
            ) {
                Text(profile.name, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                Text(
                    subtitle,
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            TextButton(onClick = onEdit) { Text("Modifier") }
        }
    }
}
