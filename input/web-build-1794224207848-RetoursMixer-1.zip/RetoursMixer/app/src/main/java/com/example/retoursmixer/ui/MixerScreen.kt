package com.example.retoursmixer.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.retoursmixer.MixerViewModel
import com.example.retoursmixer.Screen
import com.example.retoursmixer.data.Profile
import com.example.retoursmixer.data.resolveTracks

@Composable
fun MixerScreen(vm: MixerViewModel, profile: Profile) {
    val accent = profileColor(profile.colorIndex)
    val locked = vm.lockedProfileId == profile.id
    var showUnlock by remember { mutableStateOf(false) }
    val resolved = resolveTracks(vm.tracks, profile)

    Column(Modifier.fillMaxSize()) {
        // ----- Barre du haut -----
        // Ligne 1 : nom du profil sur toute la largeur + état de la connexion
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 16.dp, end = 12.dp, top = 8.dp, bottom = 2.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(
                Modifier
                    .size(12.dp)
                    .clip(CircleShape)
                    .background(accent)
            )
            Text(
                text = (if (locked) "🔒 " else "") + profile.name,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier
                    .weight(1f)
                    .padding(horizontal = 8.dp)
                    .pointerInput(locked) {
                        if (locked) {
                            detectTapGestures(onLongPress = { showUnlock = true })
                        }
                    },
            )
            ConnectionBadge(vm.connected)
        }
        // Ligne 2 : boutons (masqués en mode verrouillé)
        if (!locked) {
            val tight = PaddingValues(horizontal = 8.dp)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                TextButton(onClick = { vm.back() }, contentPadding = tight) { Text("‹ Retour") }
                Spacer(Modifier.weight(1f))
                TextButton(
                    onClick = { vm.go(Screen.Editor(profile.id)) },
                    contentPadding = tight,
                ) { Text("Modifier") }
                TextButton(onClick = { vm.lockOn(profile.id) }, contentPadding = tight) {
                    Text("Verrouiller")
                }
            }
        }

        // ----- Bandeau d'erreur de connexion -----
        if (!vm.connected) {
            Text(
                text = "Pas de réponse d'Ableton (${vm.host}:${vm.sendPort}). " +
                    "Vérifie le Wi-Fi, l'adresse IP et que AbletonOSC est actif." +
                    (vm.errorMessage?.let { "\n$it" } ?: ""),
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.error,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp),
            )
        }

        // ----- Faders -----
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
        ) {
            if (resolved.tracks.isEmpty()) {
                val msg = when {
                    resolved.groupMissing -> "Le groupe « ${profile.groupName} » est introuvable dans Ableton.\n" +
                        "Vérifie son nom exact (menu Modifier)."
                    vm.tracks.isEmpty() -> "En attente de la liste des pistes d'Ableton…"
                    else -> "Aucune piste à afficher pour ce profil."
                }
                Text(
                    text = msg,
                    textAlign = TextAlign.Center,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier
                        .align(Alignment.Center)
                        .padding(24.dp),
                )
            } else {
                BoxWithConstraints(Modifier.fillMaxSize()) {
                    val stripWidth = (maxWidth / resolved.tracks.size).coerceIn(84.dp, 150.dp)
                    LazyRow(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 6.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.spacedBy(4.dp, Alignment.CenterHorizontally),
                    ) {
                        items(resolved.tracks, key = { it.index }) { t ->
                            DisposableEffect(t.index) {
                                vm.trackShown(t.index)
                                onDispose { vm.trackHidden(t.index) }
                            }
                            ChannelStrip(
                                track = t,
                                profile = profile,
                                accent = accent,
                                onVolume = { v -> vm.setVolume(t, v) },
                                onVolumeEnd = { vm.volumeGestureEnd(t) },
                                onMute = { vm.toggleMute(t) },
                                modifier = Modifier
                                    .width(stripWidth)
                                    .fillMaxHeight(),
                            )
                        }
                    }
                }
            }
        }
    }

    if (showUnlock) {
        AlertDialog(
            onDismissRequest = { showUnlock = false },
            title = { Text("Déverrouiller ?") },
            text = { Text("Tu pourras de nouveau changer de profil et modifier les réglages.") },
            confirmButton = {
                TextButton(onClick = {
                    showUnlock = false
                    vm.unlock()
                }) { Text("Déverrouiller") }
            },
            dismissButton = {
                TextButton(onClick = { showUnlock = false }) { Text("Annuler") }
            },
        )
    }
}
