package com.example.retoursmixer.data

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/**
 * Une piste Ableton telle qu'elle est vue par l'appli.
 * Chaque champ est un état Compose : seul le composant qui lit un champ est redessiné
 * quand il change (important pour les vumètres, mis à jour ~10 fois par seconde).
 */
class TrackUi(val index: Int, name: String) {
    var name by mutableStateOf(name)
    var isGroup by mutableStateOf(false)
    var isGrouped by mutableStateOf(false)
    var volume by mutableFloatStateOf(0f)
    var mute by mutableStateOf(false)
    var level by mutableFloatStateOf(0f)

    /** Dernière valeur reçue d'Ableton ; [level] (affiché) glisse vers elle à 60 images/s. */
    var levelTarget = 0f

    // Horodatages (SystemClock.uptimeMillis) pour ne pas écraser un geste en cours par une réponse d'Ableton.
    var touchedVolumeAt = 0L
    var touchedMuteAt = 0L
    var levelAt = 0L
}

/**
 * Un profil = une interface de retour (par ex. celle de Will).
 *  - groupName : nom du groupe Ableton à afficher (vide = pas de groupe)
 *  - nameFilter : si pas de groupe, ne garde que les pistes dont le nom contient ce texte
 *  - hidden : noms de pistes masquées dans ce profil
 *  - maxVolume : limite haute du fader (0.85 = 0 dB dans Ableton), protège les oreilles
 */
data class Profile(
    val id: String = UUID.randomUUID().toString(),
    val name: String = "Nouveau profil",
    val groupName: String = "",
    val nameFilter: String = "",
    val showGroupFader: Boolean = false,
    val showMute: Boolean = true,
    val showMeters: Boolean = true,
    val maxVolume: Float = 0.85f,
    val hidden: Set<String> = emptySet(),
    val colorIndex: Int = 0,
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("name", name)
        put("groupName", groupName)
        put("nameFilter", nameFilter)
        put("showGroupFader", showGroupFader)
        put("showMute", showMute)
        put("showMeters", showMeters)
        put("maxVolume", maxVolume.toDouble())
        put("hidden", JSONArray(hidden.toList()))
        put("colorIndex", colorIndex)
    }

    companion object {
        fun fromJson(o: JSONObject): Profile = Profile(
            id = o.optString("id", UUID.randomUUID().toString()),
            name = o.optString("name", "Profil"),
            groupName = o.optString("groupName", ""),
            nameFilter = o.optString("nameFilter", ""),
            showGroupFader = o.optBoolean("showGroupFader", false),
            showMute = o.optBoolean("showMute", true),
            showMeters = o.optBoolean("showMeters", true),
            maxVolume = o.optDouble("maxVolume", 0.85).toFloat().coerceIn(0.1f, 1f),
            hidden = o.optJSONArray("hidden")?.let { a ->
                (0 until a.length()).map { a.getString(it) }.toSet()
            } ?: emptySet(),
            colorIndex = o.optInt("colorIndex", 0),
        )
    }
}

/** Aucun profil au premier lancement : on les crée soi-même depuis l'écran d'accueil. */
fun defaultProfiles(): List<Profile> = emptyList()

fun profilesToJson(list: List<Profile>): String =
    JSONArray().also { arr -> list.forEach { arr.put(it.toJson()) } }.toString()

fun profilesFromJson(raw: String): List<Profile> {
    val arr = JSONArray(raw)
    return (0 until arr.length()).map { Profile.fromJson(arr.getJSONObject(it)) }
}

// ---------- Résolution des pistes d'un profil ----------

class ResolvedTracks(val tracks: List<TrackUi>, val groupMissing: Boolean)

/**
 * Pistes enfants d'un groupe : celles qui suivent la piste de groupe dans l'ordre de Live
 * et dont is_grouped est vrai. Pour un groupe de premier niveau, les sous-groupes sont inclus.
 */
fun childrenOf(all: List<TrackUi>, header: TrackUi): List<TrackUi> {
    val out = ArrayList<TrackUi>()
    var i = header.index + 1
    while (i < all.size) {
        val t = all[i]
        if (!t.isGrouped) break
        if (t.isGroup && header.isGrouped) break // groupe imbriqué : on s'arrête au prochain groupe
        out.add(t)
        i++
    }
    return out
}

fun resolveTracks(all: List<TrackUi>, p: Profile): ResolvedTracks {
    val g = p.groupName.trim()
    val f = p.nameFilter.trim()
    var missing = false

    val base: List<TrackUi> = if (g.isNotEmpty()) {
        val header = all.firstOrNull { it.isGroup && it.name.trim().equals(g, ignoreCase = true) }
        if (header == null) {
            missing = all.isNotEmpty()
            emptyList()
        } else {
            val kids = childrenOf(all, header)
            if (p.showGroupFader) listOf(header) + kids else kids
        }
    } else if (f.isNotEmpty()) {
        all.filter { it.name.contains(f, ignoreCase = true) }
    } else {
        all
    }

    return ResolvedTracks(base.filter { it.name !in p.hidden }, missing)
}
