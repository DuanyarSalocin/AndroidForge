# Ninth Retour Live — mixeur de retours pour Ableton (Android)

Appli Android (Kotlin + Jetpack Compose) qui pilote Ableton Live via OSC :
faders de volume, mute, vumètres en temps réel, liste de pistes récupérée
automatiquement, et **un profil par musicien** qui n'affiche que son groupe de retours.

## 1. Côté Ableton (une seule fois)

1. Télécharge **AbletonOSC** : https://github.com/ideoforms/AbletonOSC
2. Copie le dossier `AbletonOSC` dans le dossier *MIDI Remote Scripts* de Live :
   - Windows : `C:\Users\<toi>\Documents\Ableton\User Library\Remote Scripts\`
   - macOS : `~/Music/Ableton/User Library/Remote Scripts/`
3. Dans Live : Préférences > Link, Tempo & MIDI > *Control Surface* : choisis **AbletonOSC**.
   Un message « AbletonOSC: Listening for OSC on port 11000 » apparaît.
4. Autorise Live dans le pare-feu de l'ordinateur (UDP 11000 en entrée).
5. Le PC et les téléphones doivent être sur le **même réseau Wi-Fi** (idéalement un routeur dédié,
   pas le Wi-Fi de la salle). Note l'adresse IP du PC.

## 2. Compiler l'appli

1. Ouvre le dossier `RetoursMixer` dans **Android Studio** (Gradle 8.9 est téléchargé et
   synchronisé tout seul ; pas de `gradlew` fourni, compile depuis Android Studio).
2. Branche un téléphone (mode développeur + débogage USB) et lance l'appli (▶),
   ou *Build > Build APK* pour distribuer l'APK aux musiciens.

> Le projet n'a pas pu être compilé dans l'environnement où il a été généré : si Android Studio
> signale une erreur de compilation, copie-la-moi et je corrige.

## 3. Utilisation

1. **Réglages** : saisis l'IP du PC (ports 11000 / 11001 par défaut) puis *Appliquer*.
   Le voyant passe au vert quand Ableton répond.
2. Au premier lancement, aucun profil n'existe : crée-les avec *+ Nouveau profil*
   (par ex. « Will » assigné au groupe « Retours Will »), puis *Modifier* pour les ajuster.
3. Dans l'éditeur d'un profil : choix du groupe (détecté automatiquement dans Ableton), fader du
   groupe lui-même, bouton Mute, vumètres, **limite haute du fader**, couleur, et
   pistes à masquer.
4. **Verrouiller** (dans l'écran du mixeur) : le téléphone du musicien démarre directement sur son
   profil et ne peut plus en sortir. Pour déverrouiller : **appui long sur le nom du profil**.
5. **Copier les profils** (Réglages) : configure tout sur un téléphone, copie, envoie le texte aux
   autres musiciens, puis *Importer* sur leur téléphone.

## Structure Ableton attendue

```
Métronome                 (piste normale)
Samples                   (piste normale)
Retours Will              (GROUPE)
   Métronome Will
   Samples Will
Retours Nico              (GROUPE)
   Métronome Nico
   Samples Nico
```

Le profil « Will » est lié au nom du groupe `Retours Will` : il affiche ses pistes enfants.
Si tu renommes un groupe dans Live, mets le profil à jour. Pas de groupes ? Le champ
« pistes dont le nom contient… » permet par exemple de filtrer sur `Will`.

## Comment ça marche

- AbletonOSC reçoit sur UDP 11000 et répond sur le port 11001 **de l'IP qui a posé la question**.
- L'appli demande la liste des pistes (`/live/song/get/track_names`) et leur type
  (`is_foldable` = groupe, `is_grouped` = dans un groupe) toutes les 3 s : si tu ajoutes ou
  déplaces une piste en cours de route, l'interface se met à jour seule.
- Pour les pistes **affichées à l'écran uniquement** : vumètres à 10 Hz
  (`output_meter_level`), volume / mute à 2 Hz. Ainsi chaque téléphone reçoit ses propres
  réponses, même avec plusieurs musiciens connectés en même temps.
- Mouvements de fader : `/live/track/set/volume <piste> <0..1>`, regroupés toutes les 30 ms.

## À savoir

- **Fader en glissement relatif** : toucher le fader ne fait pas sauter le volume, seul le
  mouvement du doigt le change. Le trait blanc épais est le repère 0 dB (valeur 0.85 dans Live).
- **Limite haute** : un musicien ne peut pas dépasser la valeur fixée dans son profil
  (par défaut 0 dB). Utile pour protéger les oreilles en in-ear.
- **Groupes imbriqués** : fiable pour des groupes de premier niveau (cas décrit ci-dessus).
- Ce qui est modifié dans Live (volume, mute) est reflété dans l'appli en ~0,5 s.
- Pour qu'un téléphone ne quitte pas l'appli en concert, tu peux en plus activer
  l'« épinglage d'écran » d'Android.
